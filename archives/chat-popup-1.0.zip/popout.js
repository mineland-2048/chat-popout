/**
 * Chat-popout
 * A web app messaging popper
 * 
 * Original author: mineland (Andy)
 * 
 * This extension makes web chat messenger sites have a more compact friendly design
 * thats more usuable for popping in and out without taking much screen space
 * 
 * Currently works only on Whatsapp Web, but there is plans to expand into others
*/

// this is the main script for the extension. The documentation should be done better, but eh, im pretty new to this.


/**
 *  A <style> element for the popCSS since having a variable be the innerHTML of an element is not fun (?)
 *  Insert this element at the start once its been filled in with the desired css in its innerHTML
*/
const styleElement = document.createElement("style");


/**
 * Checks for which site this is on and assigns the specified function to run
 * @returns 
*/
function startExtension() {
    let siteURL = window.location.host; // "web.whatsapp.com", "discord.com"
    let website = "siteURL";

    /**
     * The thing do be starting tho
     */
    let startTheThing = function () {};

    switch(siteURL) {
        case "web.whatsapp.com" :
            website = "Whatsapp";
            startTheThing = Whatsapp;
        break;

        default:
            return;

    }

    console.info(`Loading chat popout for ${website}`);
    startTheThing();
}

startExtension();


/**
 * Sets all attributes from a list into a specified element
 * @param {HTMLElement} element 
 * @param {Object} list 
 */
function insertAttributes(element, list) {

    for(const attribute in list) {
        element.setAttribute(attribute, list[attribute]);
    }

}

// The icons were made by me and are on /icons 
// -Andy
/**
 * Returns the On icon as a text form svg.
 * @param {string} color 
 * @returns HTMLElement
 */
function generateIconOn(color) {
    if (!color) { color = "#e0e0e0"; }
    let svgParent = document.createElement("span");

    /* this is the icons/full.svg pasted in because color is important*/ //xml
    svgParent.innerHTML =
    `<svg
    class="popIconOn" 
    width="5.3469601mm"
    height="5.3474774mm"
    viewBox="0 0 5.3469601 5.3474774"
    version="1.1"
    id="svg1"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:svg="http://www.w3.org/2000/svg"><defs
      id="defs1" /><g
      id="layer2"
      transform="translate(-104.86977,-17.912374)"><g
        id="g73"><path
          fill="iconColorHere"
          d="m 104.86977,17.912373 v 1.428853 l 0.36483,1.244885 -0.36483,1.244886 v 1.428853 h 1.42885 l 1.24488,-0.364836 1.24489,0.364836 h 1.42834 v -1.428853 l -0.36432,-1.244886 0.36432,-1.245402 v -1.428336 h -1.42782 l -1.24541,0.364835 -1.24488,-0.364835 z"
          style="stroke-width:1.29215;stroke-linecap:round"
          id="path70" /></g></g></svg>`;

    
    let svgElement = svgParent.children.item(0);
    svgElement.querySelector('[fill="iconColorHere"]').setAttribute("fill", color);


    return svgElement;
}

/**
 * Returns the Off icon as a text form svg.
 * @param {string} color 
 * @returns HTMLElement
 */
function generateIconOff(color) {
        
    if (!color) { color = "#e0e0e0"; }
    let svgParent = document.createElement("span");

    /* this is the icons/full.svg pasted in because color is important*/ //xml
    svgParent.innerHTML =  
    `<svg
    class="popIconOff" 
    width="5.3469524mm"
    height="5.3474774mm"
    viewBox="0 0 5.3469524 5.3474774"
    version="1.1"
    id="svg1"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:svg="http://www.w3.org/2000/svg"><defs
      id="defs1" /><g
      id="layer2"
      transform="translate(-90.993059,-18.104839)"><g
        id="g74"
        transform="translate(3.0454413,7.8273318)"
        style="display:inline"><path
          fill="iconColorHere"
          d="m 87.947612,10.277506 v 1.428853 l 0.36484,1.244886 -0.36484,1.244885 v 1.428853 h 1.42885 l 1.24489,-0.364835 1.24488,0.364835 h 1.42834 V 14.19613 l -0.36432,-1.244885 0.36432,-1.245402 v -1.428337 h -1.42782 l -1.2454,0.364836 -1.24489,-0.364836 z m 0.56224,0.56224 h 1.1281 l 0.41547,0.121439 0.002,3.979086 -0.41703,0.122473 h -1.12809 V 13.93413 l 0.28783,-0.982885 -0.28783,-0.982886 z"
          style="stroke:none;stroke-width:1.29215;stroke-linecap:round;stroke-opacity:1"
          id="path72" /></g></g></svg>`;

    let svgElement = svgParent.children.item(0);

    svgElement.querySelector('[fill="iconColorHere"]').setAttribute("fill", color);
      
    return svgElement;
    
}

/**
 * Toggles the popped out style for the current website.
 * @returns 
 */
function togglePopped() {

    let mode = document.documentElement.getAttribute("chat-popped");
    console.info(mode);

    if (mode == "true") {
        console.log("setting false");
        document.documentElement.setAttribute("chat-popped", "false");
        return;
    }
    
    console.log("setting true");
    document.documentElement.setAttribute("chat-popped", "true");

}

/**
 * Checks if the document is popped or not
 * @returns bool
 */
function isPopped() {
    if (document.documentElement.getAttribute("chat-popped") == "true") { return true; }
    return false;
}




// Set every website either down here or in separate files
// Plans: messenger, discord, idk what else
// Discord actually has an ok mobile ui. Know this because of MS Edge having ok compat with it.
// Whatsapp was the main annoyance i had, which was the primary reason for the creation of this extension.
// If anyone wants to expand this, go for it. But beware of the jank.


/**
 * This is the whole engine for Whatsapp Web. You can use this as a guide on how to modify your desired page.
 * Its awful, so beware of the jank.
 */
function Whatsapp (){

    const app = document.getElementById("app");
    let parentElement = "";
    let chat = "";
    let contacts = "";
    let info = "";

    // popCSS //
    /**
     * change this css to the one in /css/whatsapp.css whenever a change is applied there
     * TODO: fix this terrible mess to actually browser.insertCSS() or something because
     * it currently just inserts a new <style> into the head of the document.
     * Kinda messed up if you ask me
     * -Andy
     */
    styleElement.innerHTML = //css 
    `/*  This is for whatsapp web. Should probably learn how to insert css into those specifically */
 
@keyframes slide-in {
    from {            
        transform: translateY(-2vh);
        opacity: 0;
    }

    to {
        transform: translateY(0vh);
        opacity: 1;
    }
}

@keyframes pop-in {
    from {
        transform: scale(0.9);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

@keyframes pop-out {
    from {
        transform: scale(1.1);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}


.popToggleButton {
    cursor: pointer;

    span {
        display: flex;
        align-items: center;
        justify-items: center;
    }
}

.popIconOn { display: none; }
.popIconOff { display: initial; }

html[playAnim="animPopin"] {
    animation: pop-in 200ms ease;
}

html[playAnim="animPopout"] {
    animation: pop-out 200ms ease;
}


html[chat-popped='true'] {
    animation: pop-in 200ms ease;


    
    .popIconOn { display: initial; }
    .popIconOff { display: none; }

    body {
        #parentElement > div > * {
            max-width: none;
            width: 100vw;
        }

        #app > div {
            /* some pop out windows like change theme */

            /* the wrapper that has a set width */
            .s4r5ooj2 {
                min-width: 0;
                max-width: 100vw;
            }

            span:nth-child(3) {
                /* the popup message and the community pop up window respectively*/
                .hblzrxh7, .enheoddn {
                    width: 100vw;
                    max-width: 100vw;
                    min-width: 0;
                }

                .enheoddn {
                    padding-left: 32px;
                    padding-right: 32px;
                }

                /* edit message box */
                div.gpw48i3y {
                    max-width: 100vw;
                }
            }

            /* keyboard shortcuts screen's text box*/
            .iuhl9who {
                max-width: 100vw;
            }

            /* Its inner text content */
            .nfnc8vpt {
                max-width: 100vw;
                width: unset;
                min-width: 0;
            }
            
        
            > div:nth-last-child(1) {
                position: absolute;
                left: 0;
                top: 0;
                width: 100vw;
                height: 100vh;

                > div {
                    max-width: 100vw;
                    position: fixed;
                }
            }

            /* Status fixes  and fullscreen media view (images)*/
            > span:nth-child(4) {
                top: 0;
                left: 0;
                /* progress bar */
                > * {
                    position: fixed;
                    width: 100vw;
                    height: 100vh;
                    z-index: 1000;
                }

                
                
                
                /* ITS THE WHOLE PATH BECAUSE REUSED CLASS F- */
                .bgigc5s4
                {
                    max-width: 100vw;

                }
                /* status specific */
                .bmhhosgr {
                    width: unset !important;
                    max-width: 100vw;
                }

                /* back arrow and close button which basically do the same thing?*/
                /* TODO: couple the back arrow and pfp like in the chats thing*/
                .q177n8ra {
                    display: none;
                    top: 55px
                }
            }
        }
    }

    #pop-menus {
        position: fixed;

        > * {
            position: fixed;
            top: 0;
            left: 0;
            max-width: 100vw;
            min-width: 0;
        }

        /* the file upload screen */
        > div:nth-last-child(1) div.fhf7t426:nth-child(1) {
            position: fixed;
            top:0;
            left:0;
            width: 100vw;
            height: 100vh;
            min-width: 0;
            max-width: 100vw;

            .opp68qpq {
                text-align: center;
            }
        }

        div.ebjesfe0 {
            z-index: 10;
            position: absolute;
        }
    }

    #main {
        animation: pop-in 200ms ease;
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;
        transform-origin: center;

        width: 100vw;
        height: 100vh;
        top: 0vh;
        left: 0px;
        z-index: 100;
    }

    #contacts {
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;

        width: 100vw;
        height: 100vh;
        bottom: 0px;
        left: 0px;
        z-index: 1;

    }

    #parentElement > div {
        max-width: 100vw;
    }
    #parentElement > div:nth-last-child(2) {
        opacity: 1;
    }

    #info {
        position: fixed;
        top:0;
        left: 0;
        width: 100vw;
        height: 100vh;
        overflow: visible;

        transform: translateX(100vw); 

        > * > * {
            translate: -100vw;
            z-index: 200;
        }

        
        /* the media section images*/
        /* > span > div > span > div > div:nth-last-child(1) > span > div > div > div > div > div > div */
        .d0st09ow
        {
            max-width: 87%;
            --size: 200px;
            width: var(--size);

        }

        /* the media secion time labels */
        .ee0xuasv {
            width: 100%;
            margin-left: 2vw;
        }

    }

    #parentElement::after {
        display: none;
    }

    #parentElement {
        position: fixed;
        width: 100vw;
        height: 100vh;
        top: 0;
        left: 0;
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;
    }

    #main > header {
        padding-top: 0;
        padding-bottom: 0;
    }

    .backButton {
        display: flex;
        flex-direction: columns;
        align-items: center;
        pointer-events: initial;
        border-radius: 22px !important;
        margin: 0 !important;
        padding: 2px !important;
        height: 44px;
        
        > div {
            padding: 0 !important;
            margin: 0;
            pointer-events: none;
        }
    }

    .backButton + div {
        padding-left: var(--chat-spacing) !important;
        height: 100%;
        border-radius: 0px !important;
        flex-shrink: 1;
    }

    #chat[shown="true"] {
        z-index: 50;
    }
}

html[chat-popped="false"] {
    animation: pop-out 200ms ease;
    .something { display: none;}
    .backButton {
        display: flex;
        flex-direction: columns;
        align-items: center;
        pointer-events: none;

        > span {
            display: none;
        }
        
        > * {
            pointer-events: initial;
        }
    }
}`;

    stopTheThing = ()=>{
        document.getElementById("ohgod").remove();
    }


    /**
     * Handles the events for clicking ui elements.
     * @param {Event} e 
     */
    function clickEvents(e) {

        const target = e.target
        let triggerList = {
            "#pane-side > div:nth-child(1)": "enterChat",
            ".backButton" : "contacts",
            ".popToggleButton": "togglePopped"
        }

        /**
         * Finds if it has a parent thats been assigned to an event. 
         * @returns string
         */
        function findParent() {
            // console.warn(triggerList)
            for(triggerClass in triggerList) {
                // console.log(triggerClass)
                if (target.closest(triggerClass)) {
                    // console.info(triggerList[triggerClass]);
                    return triggerList[triggerClass];
                }
            }
            return "";
        }

        let trigger = findParent();

        // Triggers an event based on the trigger
        switch(trigger) {
            case "enterChat":
                enterChat();
                break;

            case "contacts":
                contactListOpen();
                break;

            case "togglePopped":
                togglePopped();
                enterChat();
                break;

        }

    }

    /**
     * checks if the #main element exists and removes the chats shown attribute if it doesnt
     * @returns bool
     */
    function mainExists() {
        if (!document.querySelector("#main")) {
            // console.log("doesnt exist"); 
            chat.removeAttribute("shown"); 
            return false;
        }
        // console.log("exists")
        return true;
    }


    /**
     * Closes the chat window and opens the contact list
     * @returns 
     */
    function contactListOpen() {        
        if (!mainExists()) return;

        contacts.setAttribute("playAnim", "animPopout");
        
        // I have no idea what function is responsible for taking the whole chat window back to its original state
        // This is a hack for the manually added back button on the contacts
        var key = new KeyboardEvent('keydown', {'key': 'Escape'});
        document.dispatchEvent(key);

        // chat.style.setProperty("z-index", "-10");
        chat.removeAttribute("shown");
        
        // console.log(chat);
        // console.log(event);
    }

    /**
     * Enters the main chat window
     * @returns 
     */
    function enterChat() {
        
        // Checks if the main chat window or back button for said chat window exists to not do anything more.
        if (!mainExists() || document.querySelector("#backButton") || !isPopped()) return;
        
        contacts.removeAttribute("playAnim");
        // The process of adding the back button
        let header = chat.querySelector("header");
        let pfpButton = chat.querySelector("header > div:nth-child(1)");
        let backButton = document.createElement("button");

        backButton.id = "backButton";

        // Icon taken from the site's other menus with actual back arrows
        backButton.innerHTML = //html
        `
                <span data-icon="back" class="">
                    <svg viewBox="0 0 24 24" height="24" width="24" preserveAspectRatio="xMidYMid meet" class="" version="1.1" x="0px" y="0px" enable-background="new 0 0 24 24">
                        <title>back</title>
                        <path fill="currentColor" d="M12,4l1.4,1.4L7.8,11H20v2H7.8l5.6,5.6L12,20l-8-8L12,4z"></path>
                    </svg>
                </span>
        `;

        // Sets the button into the profile settings back button classes. Do they change on updates? 
        // I dont like these names
        // _3OtEr is the button class so that it changes color when clicked
        backButton.className = "backButton kk3akd72 dmous0d2 fewfhwl7 ajgl1lbb ltyqj8pj _3OtEr";

        // Hijacks the Profile picture that is used to open the profile into a button to take you back to the contacts list
        // similar to how it works on the mobile app
        header.insertAdjacentElement("afterbegin", backButton);
        backButton.insertAdjacentElement("beforeend", pfpButton)

        // adds the button class to the contact name so that it changes color aswell like it does on the mobile app
        header.querySelector(".backButton + div").className += " _3OtEr";
        
        chat.setAttribute("shown", "true");
    }

    /**
     * Initializes a lot of ids for easier name access and other stuff
     */
    function init() {
        
        // browser.tabs.insertCSS({file: 'whatsapp.css'});
        popMenus =  document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(4)");
        contacts =  document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(3)");
        chat =      document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(2)");
        info =      document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(1)");
        parentElement =    document.querySelector("#app > div > :nth-last-child(1)");
        parentElement.id = "parentElement"
        
        popMenus.id = "pop-menus";
        contacts.id = "contacts";
        chat.id = "chat";
        info.id = "info";
        
        // The page has an annoying tab navigation that opens the chat window if focused
        app.addEventListener("focusin", () => { enterChat(); })

        // Adds the Pop toggle button to the header of the contacts to turn off the effects of the extension
        // Would like it if people could use the same icon as in here for consistency sake.
        if (! document.querySelector(".popToggleButton")) {

            // Button layout:
            // div(parent) > div(parentWrapper) > span(wrapper) > svg

            let headerButtonsElement = document.querySelector("#contacts > header > div:nth-last-child(1) > div > span");
            let toggleButtonParent = document.createElement("div");
            let toggleButton = document.createElement("div");
            let spanWrapper = document.createElement("span");

            // Sets classes to be the same as its neighbours
            // these messy class names are from the whatsapp ui picked by hand.
            // TODO: maybe grab these programatically with query selectors in case it ever changes?
            toggleButtonParent.className = "_3OtEr rOo0o";
            
            toggleButton.className = "_3ndVb fbgy3m38 ft2m32mm oq31bsqd nu34rnf1 popToggleButton";
            // Should probably set this so that it can be localized later
            toggleButton.ariaLabel = "Toggle popout";
            toggleButton.title = "Toggle popout";


            // Creates the icons for when popped and not.
            let iconOn = generateIconOn("currentcolor");;
            let iconOff = generateIconOff("currentcolor");

            // Appends the icons to the button
            spanWrapper.appendChild(iconOn);
            spanWrapper.appendChild(iconOff);
            
            // Ojo: outerHTML can only be used after its on a node already.
            // "currentcolor" is the color that the other buttons use for their icons
            
            // Appends the wrapper to its parent-wrapper
            toggleButton.appendChild(spanWrapper);

            // Appends the parent-wrapper into the parent
            toggleButtonParent.appendChild(toggleButton);
            
            // Lastly, appends the whole thing into the start of the header buttons
            headerButtonsElement.insertAdjacentElement("afterbegin", toggleButtonParent);
        }

        // Handles the events when you click on various ui stuff
        document.addEventListener("click", (e) => { clickEvents(e)}, {"passive": true})

        console.info("Chat popout has been initialized");
        document.documentElement.removeAttribute("chat-popup-loading");

    }

    /**
     * Initial load setup to check if the page is already functional.
     * @returns 
     */
    function load() {

        // Adds the css into the page or updates it if it exists already. Oh god
        if (document.querySelector("#ohgod")) { document.querySelector("#ohgod").replaceWith(styleElement);} else {
            document.head.appendChild(styleElement)
        }

        styleElement.id = "ohgod";
        document.head.appendChild(styleElement);

        // This could be used for auto updating css on a repository if any update is done.
        // If i expand this enough it would be fun to try this maybe.
        // 
        // let styleLink = document.createElement("link");
        // styleLink.id = "ohgodLink";
        // styleLink.rel = "stylesheets"
        // styleLink.href = browser.runtime.getURL("css/whatsapp.css");

    
        // Pops the window up (sets the popped ui)
        document.documentElement.setAttribute("chat-popped", "true");
        document.documentElement.setAttribute("chat-popup-loading", "true");
    
        // Hack to see if Whatsapp specifically has already started when the extension was called.
        if (document.querySelector("#app > div > :nth-child(8)")) { init(); return;}


        // If not, it means the site is loading in. 
        // Wait until the first animation finishes loading to do anything. 
        // There has to be a better way to do this surely
        app.addEventListener("animationend", (e) => { init(); } , { once: true});
    }


    load();

}