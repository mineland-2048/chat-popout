
Chat-popout
A web app messaging popper

Original author: mineland

This extension makes web chat messenger sites have a more compact friendly design thats more usuable for popping in and out without taking much screen space

Currently works only on Whatsapp Web, but there is plans to expand into others

Current version: 1.0
Zip date: 2/13/24

