/**
 * Chat-popout
 * A web app messaging popper
 * 
 * Original author: mineland (Andy)
 * 
 * This extension makes web chat messenger sites have a more compact friendly design
 * thats more usuable for popping in and out without taking much screen space
 * 
 * Currently works only on Whatsapp Web, but there is plans to expand into others
*/

// this is the main script for the extension. The documentation should be done better, but eh, im pretty new to this.


/**
 *  A <style> element for the popCSS since having a variable be the innerHTML of an element is not fun (?)
 *  Insert this element at the start once its been filled in with the desired css in its innerHTML
*/
const styleElement = document.createElement("style");
let siteURL = window.location.host; // "web.whatsapp.com", "discord.com"
let website = "siteURL";


/**
 * Checks for which site this is on and assigns the specified function to run
 * @returns 
*/
function startExtension() {
    // console.log(siteURL)

    /**
     * The thing do be starting tho
     */
    let startTheThing = function () {};

    switch(siteURL) {
        case "web.whatsapp.com" :
            website = "Whatsapp";
            startTheThing = Whatsapp;
        break;

        case "discord.com" :
            website = "Discord";
            startTheThing = Discord;
        break;

        default:
            return;

    }

    console.info(`Loading chat popout for ${website}`);
    startTheThing();
}

startExtension();

///////////////////////////////
//                           //
//  USEFUL GLOBAL FUNCTIONS  //
//                           //
///////////////////////////////

/**
 * Logs that the extension has ben loaded in site
 * @param {string} site The website
 */
function logReady(site) {
    if (!site) site =  website; 
    console.info(`Chat popout has been initialized for ${site}`);
}

/**
 * Sets all attributes from a list into a specified element
 * @param {HTMLElement} element 
 * @param {Object} list 
 */
function insertAttributes(element, list) {

    for(const attribute in list) {
        element.setAttribute(attribute, list[attribute]);
    }

}

// The on and off icons were made by me and are on /icons 
// -Andy

/**
 * Returns the On icon as a text form svg.
 * @param {string} color 
 * @returns HTMLElement
 */
function generateIconOn(color) {
    if (!color) { color = "#e0e0e0"; }
    let svgParent = document.createElement("span");

    /* this is the icons/full.svg pasted in because color is important*/ //xml
    svgParent.innerHTML =
    `<svg
    class="popIconOn" 
    width="5.3469601mm"
    height="5.3474774mm"
    viewBox="0 0 5.3469601 5.3474774"
    version="1.1"
    id="svg1"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:svg="http://www.w3.org/2000/svg"><defs
      id="defs1" /><g
      id="layer2"
      transform="translate(-104.86977,-17.912374)"><g
        id="g73"><path
          fill="iconColorHere"
          d="m 104.86977,17.912373 v 1.428853 l 0.36483,1.244885 -0.36483,1.244886 v 1.428853 h 1.42885 l 1.24488,-0.364836 1.24489,0.364836 h 1.42834 v -1.428853 l -0.36432,-1.244886 0.36432,-1.245402 v -1.428336 h -1.42782 l -1.24541,0.364835 -1.24488,-0.364835 z"
          style="stroke-width:1.29215;stroke-linecap:round"
          id="path70" /></g></g></svg>`;

    
    let svgElement = svgParent.children.item(0);
    svgElement.querySelector('[fill="iconColorHere"]').setAttribute("fill", color);


    return svgElement;
}

/**
 * Returns the Off icon as a text form svg.
 * @param {string} color 
 * @returns HTMLElement
 */
function generateIconOff(color) {
        
    if (!color) { color = "#e0e0e0"; }
    let svgParent = document.createElement("span");

    /* this is the icons/full.svg pasted in because color is important*/ //xml
    svgParent.innerHTML =  
    `<svg
    class="popIconOff" 
    width="5.3469524mm"
    height="5.3474774mm"
    viewBox="0 0 5.3469524 5.3474774"
    version="1.1"
    id="svg1"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:svg="http://www.w3.org/2000/svg"><defs
      id="defs1" /><g
      id="layer2"
      transform="translate(-90.993059,-18.104839)"><g
        id="g74"
        transform="translate(3.0454413,7.8273318)"
        style="display:inline"><path
          fill="iconColorHere"
          d="m 87.947612,10.277506 v 1.428853 l 0.36484,1.244886 -0.36484,1.244885 v 1.428853 h 1.42885 l 1.24489,-0.364835 1.24488,0.364835 h 1.42834 V 14.19613 l -0.36432,-1.244885 0.36432,-1.245402 v -1.428337 h -1.42782 l -1.2454,0.364836 -1.24489,-0.364836 z m 0.56224,0.56224 h 1.1281 l 0.41547,0.121439 0.002,3.979086 -0.41703,0.122473 h -1.12809 V 13.93413 l 0.28783,-0.982885 -0.28783,-0.982886 z"
          style="stroke:none;stroke-width:1.29215;stroke-linecap:round;stroke-opacity:1"
          id="path72" /></g></g></svg>`;

    let svgElement = svgParent.children.item(0);

    svgElement.querySelector('[fill="iconColorHere"]').setAttribute("fill", color);
      
    return svgElement;
    
}

/**
 * Returns a generic back button svg
 * @param {string} color 
 * @returns Element
 */
function generateIconBack(color) {
    const button = document.createElement("div");

    if (!color) color = "currentcolor";

    button.innerHTML = //html
    `<svg viewBox="0 0 24 24" height="24" width="24" preserveAspectRatio="xMidYMid meet" class="" version="1.1" x="0px" y="0px" enable-background="new 0 0 24 24">
        <path fill="${color}" d="M12,4l1.4,1.4L7.8,11H20v2H7.8l5.6,5.6L12,20l-8-8L12,4z"></path>
    </svg>`;


    let icon = button.children.item(0);

    return icon;
}

/**
 * Toggles the popped out style for the current website.
 */
function togglePopped() {

    let mode = document.documentElement.getAttribute("chat-popped");
    // console.info(mode);

    if (mode == "true") {
        // console.log("setting false");
        document.documentElement.setAttribute("chat-popped", "false");
        return;
    }
    
    // console.log("setting true");
    document.documentElement.setAttribute("chat-popped", "true");

}

/**
 * Checks if the document is popped or not
 * @returns bool
 */
function isPopped() {
    if (document.documentElement.getAttribute("chat-popped") == "true") { return true; }
    return false;
}




// Set every website either down here or in separate files
// Plans: messenger, discord, idk what else
// Discord actually has an ok mobile ui. Know this because of MS Edge having ok compat with it.
// Whatsapp was the main annoyance i had, which was the primary reason for the creation of this extension.
// If anyone wants to expand this, go for it. But beware of the jank.


/**
 * This is the whole engine for Whatsapp Web. You can use this as a guide on how to modify your desired page.
 * Its awful, so beware of the jank.
 */
function Whatsapp (){

    const app = document.getElementById("app");
    let parentElement = "";
    let chat = "";
    let contacts = "";
    let info = "";

    // popCSS //
    /**
     * change this css to the one in /css/whatsapp.css whenever a change is applied there
     * TODO: fix this terrible mess to actually browser.insertCSS() or something because
     * it currently just inserts a new <style> into the head of the document.
     * Kinda messed up if you ask me
     * -Andy
     */
    styleElement.innerHTML = //css 
    `/*  This is for whatsapp web. Should probably learn how to insert css into those specifically */
 
@keyframes slide-in {
    from {            
        transform: translateY(-2vh);
        opacity: 0;
    }

    to {
        transform: translateY(0vh);
        opacity: 1;
    }
}

@keyframes pop-in {
    from {
        transform: scale(0.9);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

@keyframes pop-out {
    from {
        transform: scale(1.1);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}


.popToggleButton {
    cursor: pointer;

    span {
        display: flex;
        align-items: center;
        justify-items: center;
    }
}

.popIconOn { display: none; }
.popIconOff { display: initial; }

html[playAnim="animPopin"] {
    animation: pop-in 200ms ease;
}

html[playAnim="animPopout"] {
    animation: pop-out 200ms ease;
}


html[chat-popped='true'] {
    animation: pop-in 200ms ease;


    
    .popIconOn { display: initial; }
    .popIconOff { display: none; }

    body {
        #parentElement > div > * {
            max-width: none;
            width: 100vw;
        }

        #app > div {
            /* some pop out windows like change theme */

            /* the wrapper that has a set width */
            .s4r5ooj2 {
                min-width: 0;
                max-width: 100vw;
            }

            span:nth-child(3) {
                /* the popup message and the community pop up window respectively*/
                .hblzrxh7, .enheoddn {
                    width: 100vw;
                    max-width: 100vw;
                    min-width: 0;
                }

                .enheoddn {
                    padding-left: 32px;
                    padding-right: 32px;
                }

                /* edit message box */
                div.gpw48i3y {
                    max-width: 100vw;
                }

                > div { z-index: 2000 }
            }

            /* keyboard shortcuts screen's text box*/
            .iuhl9who {
                max-width: 100vw;
            }

            /* Its inner text content */
            .nfnc8vpt {
                max-width: 100vw;
                width: unset;
                min-width: 0;
            }
            
        
            > div:nth-last-child(1) {
                position: absolute;
                left: 0;
                top: 0;
                width: 100vw;
                height: 100vh;

                > div {
                    max-width: 100vw;
                    position: fixed;
                }
            }

            /* Status fixes  and fullscreen media view (images)*/
            > span:nth-child(4) {
                top: 0;
                left: 0;
                /* progress bar */
                > * {
                    position: fixed;
                    width: 100vw;
                    height: 100vh;
                    z-index: 1000;
                }

                
                
                
                /* ITS THE WHOLE PATH BECAUSE REUSED CLASS F- */
                .bgigc5s4
                {
                    max-width: 100vw;

                }
                /* status specific */
                .bmhhosgr {
                    width: unset !important;
                    max-width: 100vw;
                }

                /* back arrow and close button which basically do the same thing?*/
                /* TODO: couple the back arrow and pfp like in the chats thing*/
                .q177n8ra {
                    display: none;
                    top: 55px
                }
            }
        }
    }

    #pop-menus {
        position: fixed;

        > * {
            position: fixed;
            top: 0;
            left: 0;
            max-width: 100vw;
            min-width: 0;
        }

        /* the file upload screen */
        > div:nth-last-child(1) div.fhf7t426:nth-child(1) {
            position: fixed;
            top:0;
            left:0;
            width: 100vw;
            height: 100vh;
            min-width: 0;
            max-width: 100vw;

            .opp68qpq {
                text-align: center;
            }
        }

        div.ebjesfe0 {
            z-index: 10;
            position: absolute;
        }
    }

    #main {
        animation: pop-in 200ms ease;
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;
        transform-origin: center;

        width: 100vw;
        height: 100vh;
        top: 0vh;
        left: 0px;
        z-index: 100;
    }

    #contacts {
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;

        width: 100vw;
        height: 100vh;
        bottom: 0px;
        left: 0px;
        z-index: 1;

    }

    #parentElement > div {
        max-width: 100vw;
    }
    #parentElement > div:nth-last-child(2) {
        opacity: 1;
    }

    #info {
        position: fixed;
        top:0;
        left: 0;
        width: 100vw;
        height: 100vh;
        overflow: visible;

        transform: translateX(100vw); 

        > * > * {
            translate: -100vw;
            z-index: 200;
        }

        
        /* the media section images*/
        /* > span > div > span > div > div:nth-last-child(1) > span > div > div > div > div > div > div */
        .d0st09ow
        {
            max-width: 87%;
            --size: 200px;
            width: var(--size);

        }

        /* the media secion time labels */
        .ee0xuasv {
            width: 100%;
            margin-left: 2vw;
        }

    }

    #parentElement::after {
        display: none;
    }

    #parentElement {
        position: fixed;
        width: 100vw;
        height: 100vh;
        top: 0;
        left: 0;
        max-width: none;
        min-width: none;
        max-height: none;
        min-height: none;
    }

    #main > header {
        padding-top: 0;
        padding-bottom: 0;
    }

    .backButton {
        display: flex;
        flex-direction: columns;
        align-items: center;
        pointer-events: initial;
        border-radius: 22px !important;
        margin: 0 !important;
        padding: 2px !important;
        height: 44px;
        
        > div {
            padding: 0 !important;
            margin: 0;
            pointer-events: none;
        }
    }

    .backButton + div {
        padding-left: var(--chat-spacing) !important;
        height: 100%;
        border-radius: 0px !important;
        flex-shrink: 1;
    }

    #chat[shown="true"] {
        z-index: 50;
    }
}

html[chat-popped="false"] {
    animation: pop-out 200ms ease;
    .something { display: none;}
    .backButton {
        display: flex;
        flex-direction: columns;
        align-items: center;
        pointer-events: none;

        > span {
            display: none;
        }
        
        > * {
            pointer-events: initial;
        }
    }
}`;

    stopTheThing = ()=>{
        document.getElementById("ohgod").remove();
    }


    /**
     * Handles the events for clicking ui elements.
     * @param {Event} e 
     */
    function clickEvents(e) {

        const target = e.target
        let triggerList = {
            "#pane-side > div:nth-child(1)": "enterChat",
            ".backButton" : "contacts",
            ".popToggleButton": "togglePopped"
        }

        /**
         * Finds if it has a parent thats been assigned to an event. 
         * @returns string
         */
        function findParent() {
            // console.warn(triggerList)
            for(triggerClass in triggerList) {
                // console.log(triggerClass)
                if (target.closest(triggerClass)) {
                    // console.info(triggerList[triggerClass]);
                    return triggerList[triggerClass];
                }
            }
            return "";
        }

        let trigger = findParent();

        // Triggers an event based on the trigger
        switch(trigger) {
            case "enterChat":
                enterChat();
                break;

            case "contacts":
                contactListOpen();
                break;

            case "togglePopped":
                togglePopped();
                enterChat();
                break;

        }

    }

    /**
     * checks if the #main element exists and removes the chats shown attribute if it doesnt
     * @returns bool
     */
    function mainExists() {
        if (!document.querySelector("#main")) {
            // console.log("doesnt exist"); 
            chat.removeAttribute("shown"); 
            return false;
        }
        // console.log("exists")
        return true;
    }


    /**
     * Closes the chat window and opens the contact list
     * @returns 
     */
    function contactListOpen() {        
        if (!mainExists()) return;

        contacts.setAttribute("playAnim", "animPopout");
        
        // I have no idea what function is responsible for taking the whole chat window back to its original state
        // This is a hack for the manually added back button on the contacts
        var key = new KeyboardEvent('keydown', {'key': 'Escape'});
        document.dispatchEvent(key);

        // chat.style.setProperty("z-index", "-10");
        chat.removeAttribute("shown");
        
        // console.log(chat);
        // console.log(event);
    }

    /**
     * Enters the main chat window
     * @returns 
     */
    function enterChat() {
        
        // Checks if the main chat window or back button for said chat window exists to not do anything more.
        if (!mainExists() || document.querySelector("#backButton") || !isPopped()) return;
        
        contacts.removeAttribute("playAnim");
        // The process of adding the back button
        let header = chat.querySelector("header");
        let pfpButton = chat.querySelector("header > div:nth-child(1)");
        let backButton = document.createElement("button");

        backButton.id = "backButton";

        // Icon taken from the site's other menus with actual back arrows
        backButton.innerHTML = //html
        `
                <span data-icon="back" class="">
                    <svg viewBox="0 0 24 24" height="24" width="24" preserveAspectRatio="xMidYMid meet" class="" version="1.1" x="0px" y="0px" enable-background="new 0 0 24 24">
                        <title>back</title>
                        <path fill="currentColor" d="M12,4l1.4,1.4L7.8,11H20v2H7.8l5.6,5.6L12,20l-8-8L12,4z"></path>
                    </svg>
                </span>
        `;

        // Sets the button into the profile settings back button classes. Do they change on updates? 
        // I dont like these names
        // _3OtEr is the button class so that it changes color when clicked
        backButton.className = "backButton kk3akd72 dmous0d2 fewfhwl7 ajgl1lbb ltyqj8pj _3OtEr";

        // Hijacks the Profile picture that is used to open the profile into a button to take you back to the contacts list
        // similar to how it works on the mobile app
        header.insertAdjacentElement("afterbegin", backButton);
        backButton.insertAdjacentElement("beforeend", pfpButton)

        // adds the button class to the contact name so that it changes color aswell like it does on the mobile app
        header.querySelector(".backButton + div").className += " _3OtEr";
        
        chat.setAttribute("shown", "true");
    }

    /**
     * Initializes a lot of ids for easier name access and other stuff
     */
    function init() {
        
        // browser.tabs.insertCSS({file: 'whatsapp.css'});
        popMenus =  document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(4)");
        contacts =  document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(3)");
        chat =      document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(2)");
        info =      document.querySelector("#app > div > :nth-last-child(1) > :nth-last-child(1)");
        parentElement =    document.querySelector("#app > div > :nth-last-child(1)");
        parentElement.id = "parentElement"
        
        popMenus.id = "pop-menus";
        contacts.id = "contacts";
        chat.id = "chat";
        info.id = "info";
        
        // The page has an annoying tab navigation that opens the chat window if focused
        app.addEventListener("focusin", () => { enterChat(); })

        // Adds the Pop toggle button to the header of the contacts to turn off the effects of the extension
        // Would like it if people could use the same icon as in here for consistency sake.
        if (! document.querySelector(".popToggleButton")) {

            // Button layout:
            // div(parent) > div(parentWrapper) > span(wrapper) > svg

            let headerButtonsElement = document.querySelector("#contacts > header > div:nth-last-child(1) > div > span");
            let toggleButtonParent = document.createElement("div");
            let toggleButton = document.createElement("div");
            let spanWrapper = document.createElement("span");

            // Sets classes to be the same as its neighbours
            // these messy class names are from the whatsapp ui picked by hand.
            // TODO: maybe grab these programatically with query selectors in case it ever changes?
            toggleButtonParent.className = "_3OtEr rOo0o";
            
            toggleButton.className = "_3ndVb fbgy3m38 ft2m32mm oq31bsqd nu34rnf1 popToggleButton";
            // Should probably set this so that it can be localized later
            toggleButton.ariaLabel = "Toggle popout";
            toggleButton.title = "Toggle popout";


            // Creates the icons for when popped and not.
            let iconOn = generateIconOn("currentcolor");;
            let iconOff = generateIconOff("currentcolor");

            // Appends the icons to the button
            spanWrapper.appendChild(iconOn);
            spanWrapper.appendChild(iconOff);
            
            // Ojo: outerHTML can only be used after its on a node already.
            // "currentcolor" is the color that the other buttons use for their icons
            
            // Appends the wrapper to its parent-wrapper
            toggleButton.appendChild(spanWrapper);

            // Appends the parent-wrapper into the parent
            toggleButtonParent.appendChild(toggleButton);
            
            // Lastly, appends the whole thing into the start of the header buttons
            headerButtonsElement.insertAdjacentElement("afterbegin", toggleButtonParent);
        }

        // Handles the events when you click on various ui stuff
        document.addEventListener("click", (e) => { clickEvents(e)}, {"passive": true})

        logReady();
        document.documentElement.removeAttribute("chat-popup-loading");

    }

    /**
     * Initial load setup to check if the page is already functional.
     * @returns 
     */
    function load() {

        // Adds the css into the page or updates it if it exists already. Oh god
        if (document.querySelector("#ohgod")) { document.querySelector("#ohgod").replaceWith(styleElement);} else {
            document.head.appendChild(styleElement)
        }

        styleElement.id = "ohgod";
        document.head.appendChild(styleElement);

        // This could be used for auto updating css on a repository if any update is done.
        // If i expand this enough it would be fun to try this maybe.
        // 
        // let styleLink = document.createElement("link");
        // styleLink.id = "ohgodLink";
        // styleLink.rel = "stylesheets"
        // styleLink.href = browser.runtime.getURL("css/whatsapp.css");

    
        // Pops the window up (sets the popped ui)
        document.documentElement.setAttribute("chat-popped", "true");
        document.documentElement.setAttribute("chat-popup-loading", "true");
    
        // Hack to see if Whatsapp specifically has already started when the extension was called.
        if (document.querySelector("#app > div > :nth-child(8)")) { init(); return;}


        // If not, it means the site is loading in. 
        // Wait until the first animation finishes loading to do anything. 
        // There has to be a better way to do this surely
        app.addEventListener("animationend", (e) => { init(); } , { once: true});
    }


    load();

}


/**
 * Here comes the Discord
 */
function Discord() {
    const app = document.getElementById("app-mount");

    // popCSS
    styleElement.innerHTML = //css
    `
    @keyframes slideFromRight {
        from {
            translate: 100vw;
        }
    
        to {
            translate: 0;
        }
    }
    
    @keyframes popIn {
        from {
            scale: 0;
        }
    
        to {
            scale: 1;
        }
    }
        
    @keyframes fadeFromTop {
        from {
            transform: translateY(-5px);
            opacity: 0;
        }
    
        to {
            transform: translateY(0px);
            opacity: 1;
    
        }
    }
    
    /* explanation on the search section */
    @keyframes searchStayAnim {
        0% { translate: 100%; }
        10% { translate: 0; }
        90% { translate: 0; }
        100% { }
    }
    
    
    
    .togglePopButton {
        display: flex;
        align-items: center;
        justify-content: center;
    
        > div {
            display: flex;
            align-items: center;
        }
    }
    
    .settingsBackButton {
        width: 36px;
        height: 36px;
        position: relative;
        display: flex;
        top: 6px;
        /* translate: 0 -6px; */
        background-color: transparent;
        color: var(--text-normal);
        align-items: center;
        justify-content: center;
    }
    
    html[chat-popped="true"] {
    
    
        .popIconOff {
            display: none;
        }
    
        .container__037ed {
            position: fixed;
        }
    
        /* sidebar */
        .sidebar_ded4b5, nav.guilds__2b93a {
            transition: translate 200ms ease;
            z-index: 200;
            translate: -100vw;
            position: fixed;
            top: 0;
            height: 100vh;
        }
    
        .guildBackdrop {
            transition: background-color 200ms ease;
            position: fixed;
            pointer-events: none;
            top:0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: #00000000;
            z-index: 199;
        }
    
        
        
        /* settings menu */
        [class^=contentRegionScroller_]  {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
            align-content: start;
    
            h2.header-title-fix { 
                display: flex; 
                align-items: baseline; 
                position: sticky;
                top: 0px;
                width: 100vw;
                background-color: var(--background-secondary);
                z-index: 200;
                padding: 20px;
                box-shadow: var(--elevation-low);
            }
    
            h2.header-title-fix ~ .separator {
                content: '';
                display: block;
                position:relative;
                top: 0;
                left: 0;
                width: 100%;
                height: 44px;
            }
    
            h2.header-title-fix ~ .separator::before {
                content: '';
                position: absolute;
                background-color: var(--background-secondary);
                left:0;
                bottom: 0;
                margin: 30px -20px;
                width: 100vw;
                height: 300%;
    
            }
    
            [class^=toolsContainer_] {
                position: fixed;
                z-index: 200;
                right: 0;
                top: 0;
                padding-top: 0;
                /* height is the top bar computed */
                height: 76px;
                display: flex;
                justify-content: center;
                align-items: center;
    
                div[class^=keybind_] {
                    display: none;
                }
            }
    
            > div[class^=contentColumn_]{
                flex-shrink: 0;
                padding-right: 20px;
                padding-left: 20px;
                padding: 20px 20px 80px 20px;
                width: 100vw;
                max-width: 740px;
                min-height: 0;
            }
        }
        
    
        #profile-customization-tab > div:nth-child(4) > div:nth-child(1) > div{
            flex-wrap: wrap;
        }
        #privacy-\\&-safety-tab .sectionTitle_e32631 {
            display: none;
        }
        #my-account-tab > div:nth-child(1) > div:nth-child(1) {
            display: flex;
            flex-direction: column;
            width: 100%;
            div:nth-last-child(1) {
                max-width: 95vw;
                min-width: 0;
                align-self: center;
    
            }
        }
        
        div[class^=accountProfileCard__] {
            width: 100%;
            max-width: 660px;
        }
    
        div[class^=profileCustomizationSection] > div {
            flex-wrap: wrap-reverse;
        }
    
    
        /* Quick switcher */
        .notAppAsidePanel__9d124 > div:nth-child(4) {
            .container_f03f1d {
                max-width: 570px;
                width: 100vw;
    
                [class^=quickswitcher_] {
                    width: 100%;
                }
            }
            
    
        }
    
        /* sidebar wrapper */
        .standardSidebarView__1129a {
            position:fixed;
            width:100vw;
            height: 100vh;
            z-index: 210;
            
            .sidebarRegion__60457 {
                translate: -100vw;
                width: 100%;
                transition: translate 200ms ease;
    
                .sidebar__9e3e2 {
                    width: 100%;
                    padding-left: 20px;
                    padding-right: 20px;
                }
            }
    
            .contentRegion__0bec1 {
                position: fixed;
                top: 0;
                left: 0;
                width:100vw;
                height: 100vh;
    
                > div {
                    width: 100%;
                }
            }
    
        }
        
        [sidebarOpen="true"] {
            
            nav.guilds__2b93a {
                transition: translate ease 200ms;
                translate: 0px;
            }
            
            .sidebar_ded4b5 {
                transition: translate ease 200ms;
                translate: 72px;
            }
    
            .guildBackdrop {
                transition: background-color ease 200ms;
                pointer-events: initial;
                display: block;
                position: fixed;
                background-color: #00000080;
            }
    
            /* settings menu */
    
            /* sidebar wrapper */
            .standardSidebarView__1129a {
                position:fixed;
                width:100vw;
                transition: translate 200ms ease;
    
                
                .sidebarRegion__60457 {
                    translate: 0;                
                }
    
            }
        }
    
    
        /* Call toolbar */
        [class^=callContainer_] [class^=toolbar_] {
            --toolbar-width: 140px;
    
    
            .togglePopButton {
                margin-right: 16px;
    
                > div {
                    margin: 0;
                }
            }
        }
    
    
        /* chat */
        [class^=chat_] {
            /* position: relative;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh; */
            /* Toolbar width to change when in a call or on chat */
            --toolbar-width: 120px;
    
            
            main {
                position: relative;
            }
    
            /* User list */
            .container_b2ce9c {
                animation: slideFromRight 200ms ease;
                position: fixed;
                right:0;   
            }
    
    
            /* the chat header */
            .upperContainer__993ba {
                justify-content: end;
            }
            /* the toolbar at the top */
            .toolbar__88c63 {
                justify-content: end;
                overflow: hidden;
                transition: max-width 200ms ease;
                max-width: var(--toolbar-width);
            }
    
            .toolbar__88c63:hover, .toolbar__88c63:focus-within {
                transition: max-width 200ms ease;
                max-width: 100%;
            }
            
    
            
            /* the search bar */
            .searchBar_e0c60b {
                width: 24px;
            }
            
            .open_d3ab4e .searchBar_e0c60b, .focused_ddee54 .searchBar_e0c60b {
                justify-self:left;
                width: 240px
            }
    
            /* the search results and voice chat text channel*/
            /* for some damn reason floating wildcard doesnt work because of the f ?? */
            [class^=searchResultsWrap_], .floating_f021e2 {
                
    
                position: absolute;
                border-radius: 4px;
                top:0;
                bottom: 0;
                right: 0;
                translate: 80%;
                transition: translate 200ms ease;
    
                /* this one might need a bit of an explanation
                    This anim is the one that lets the message search results linger on when searching something for the first time. 
                    The transition speed im using for these is 200ms, so 2000ms / 10% = 200ms, which is 90 on the end side.
                    The blank 100% is so that it can transition smoothly into the designated transition
                    which is 80% normally or 0 when hover
                */
                animation: searchStayAnim 2s ease;
            }
    
    
    
            [class^=searchResultsWrap_]:hover, .floating_f021e2:hover{
                transition: translate 200ms ease;
                translate: 0;
            }
    
            /* removes the buttons that arent the emoji selector because they're justannoying */
            .buttons_ce5b56 > *:not(:nth-last-child(1)) {
                display: none;
            }
    
        }
    
    
        /* friends list header */
        main [class^=upperContainer__] [class^=children_] {
            overflow: scroll;
        }
    
        .notificationBadge::before {
            content: var(--notif-count);
            display: flex;
            position: absolute;
            bottom: -15px;
    
            width: 16px;
            height: 16px;
            background-color: var(--status-danger);
            color: var(--header-primary);
            border-radius: 50%;
            font-size: 12px;
            text-align: center;
            justify-content: center;
            padding: 1px;
            align-items: center;
            font-family: var(--font-display);
            font-weight: 700;
    
            transform: scale(3);
    
            animation: popIn 200ms ease;
    
    
        }
    
        /* pop ups */
        .notAppAsidePanel__9d124 > div:nth-child(4) {
            [class^=modal_] {
                pointer-events: none;
                
                > div {
                    pointer-events: initial;
                }
    
                
            }
            
            > [id^=popout_] {            
                left:0 !important;
                right: 0 !important;
                width: 100vw;
                display: flex;
                justify-content: center;
                pointer-events: none;
    
                animation: fadeFromTop 200ms ease;
    
    
    
                > * {
                    pointer-events: initial;
                    max-width: 95vw;
                    min-width: 0;
                    width: 480px;
                    position: relative;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    flex-direction: column;
    
                }
                > [role="dialog"] {
                    width:100%;
                    min-width: 0;
    
                    > div {
                        width: unset;
                        max-width: 100%;
                        max-height: 75vh !important;
                    }
                }
    
                > [role="menu"]{
                    width: fit-content;
                }
    
                > [role="listbox"] {
                    width: 100% !important;
    
                    > div[id^=uid] {
                        width: 100%;
                        justify-content: center;
                        align-content: center;
                        justify-items: center;
                        align-items: center;
                        display: flex;
    
                       
                        > div {
                            min-width: 0;
                            flex-grow: 0;
                            padding: 0 2ch;
                        }
                        > div:nth-child(2) {
                            padding-left: 0;
                        }
                    }
                    > ul {
                        width: 100%;
                    }
                } 
            }
    
            /* User profile on small sizes scroll */
            .root_ba16f0 {
                overflow: scroll !important;
            }
    
        }
    
        
    
    }
    
    html[chat-popped="false"] {
        .popIconOn {
            display: none;
        }
    
        .chatMenuButton {
            display: none;
        }
    
        .settingsBackButton {
            display: none;
        }
    
        .header-title-fix {
            display: none;
        }
    }`;


    /**
         * Initial load setup to check if the page is already functional.
         * I should probably make this a global function now that i think about it 
         */
    function load() {

        // if its the call popout window then bail
        if (window.location.href === "https://discord.com/popout") return;


        // Adds the css into the page or updates it if it exists already. Oh god
        if (document.querySelector("#ohgod")) document.querySelector("#ohgod").replaceWith(styleElement);
        else document.head.appendChild(styleElement);

        styleElement.id = "ohgod";



        // Pops the window up (sets the popped ui)
        document.documentElement.setAttribute("chat-popped", "true");
        document.documentElement.setAttribute("chat-popup-loading", "true");

        // Hack to see if Discord specifically has already started when the extension was called.


        // If not, it means the site is loading in. 
        
        /**
         * checks if the main element exists or not. If not, bail and let it retry later. 
         */
        function checkIfCanInit() {
            if (app.querySelector("[class^=upperContainer")) { 
                // console.info("it has begun");
                return true; 
            }
            // console.info("it hasnt stopped")
            return false;
        }

        const targetNode = app;
        const config = { attributes: true, childList: true, subtree: true };

        const callback = (mutationList, observer) => {
            if (checkIfCanInit()) { 
                // alert("observed");

                observer.disconnect(); 
                init();
                return;
            }
        }

        const observer = new MutationObserver(callback);
        observer.observe(targetNode, config);



        const titleElement = document.querySelector("title");

        const notifChecker = (mutationList, observer) => {
            if (!isNaN(parseInt(document.title.charAt(1)))) {
                // alert("notif");
                // REGEX EXPLANATION:
                // the first one matches the titles notification count if it exists.
                // (12) <-- looks for numbers between parenthesis ()
                // replace replaces Anything that isnt a number with blanks so its just numbers left

                let n = document.title
                    .match(/\(\d*\)/g).toString()
                    .replace(/\D/g, "");
                app.setAttribute("notifCount", n)

                app.style.setProperty("--notif-count", `'${n}'`);
            } 
            else {
                // alert("title")
;                app.setAttribute("notifCount", 0);
                app.style.setProperty("--notif-count", ``);
                
            }
        }

        const notifObserver = new MutationObserver(notifChecker);
        notifObserver.observe(titleElement, config);

        notifChecker();

        if (document.querySelector("main")) { init(); return;}



    }



    function init() {

        // alert("initd")

        // Contains the guild nav bar and the base window
        let appContainer = app.querySelector("[class^=container_]");

        // Server nav bar
        let serverNavBar = appContainer.querySelector("nav[class^=guilds_]");

        // contains the chat and sidebar
        let baseWindow = appContainer.querySelector("div[class^=base_]");

        let sidebar = baseWindow.querySelector("[class^=sidebar_");
        // let chat = baseWindow.querySelector('.chat__52833');

        let chatHeader = baseWindow.querySelector("section");
        
        let upperContainer = chatHeader.querySelector("[class^=upperContainer_]");


        // enterChat();

        const targetNode = appContainer;
        const config = { attributes: true, childList: true, subtree: true };

        const callback = (mutationList, observer) => {

            // if the pop toggle button is gone, it means that it has refreshed.
            // alert("popBUtton is gone ????");
            if (!document.querySelector(".togglePopButton") && document.querySelector("[class^=upperContainer_]")) enterChat();

            const currentMenu = app.getAttribute("menu");
            const oncall = app.getAttribute("oncall");

            if (document.querySelector("[class^=callContainer_]")) app.setAttribute("oncall", "true"); 
            else app.removeAttribute("oncall");

            // Checks if its on a call
            if (oncall == "true" && currentMenu == "chat") {
                // alert('calling')
                enterChat();
            }


        }
        
        const appObserver = new MutationObserver(callback);
        appObserver.observe(targetNode, config);


        let guildBackdrop = document.createElement("div");
        guildBackdrop.className = "guildBackdrop";


        guildBackdrop.addEventListener("click", () => { setSidebar(false);});
        if (!document.querySelector(".guildBackdrop")) {sidebar.insertAdjacentElement("afterend", guildBackdrop);
        } else { document.querySelector(".guildBackdrop").replaceWith(guildBackdrop)}

        // console.log("int start");
        
        // i didnt want to use an interval because i think it would be inefficient, but the observer just doesnt work for this reliably
        setInterval(()=> {
            const settings = app.getAttribute("settings");
            // console.log("interval");

            if (document.querySelector("[class^=standardSidebarView_]") 
                && settings !== "open") {
                // console.warn("settings");

                // alert('settings')
                enterSettings();
                return;
            }
            if (app.getAttribute("settings") == "open") { 
                app.removeAttribute("settings");
            }



        }, 150);
        
        enterChat();


        /**
         * returns wether there is a popup thing open or not
         * currently: fullscreen image; inbox and similar popups; and emoji picker
         * @returns bool
         */
        function hasPopupOpen() {
            return (
                   document.querySelector("[class^=focusLock_") 
                || document.querySelector("[id^=popout]")
                || document.querySelector("#emoji-picker-tab-panel")
            );
        }

        // esc to toggle sidebar
        document.addEventListener("keydown", (e) => { 
            if (e.key == "Escape" && !hasPopupOpen()) {
                e.preventDefault();
                toggleSidebar();
            }
        })



        // app.querySelector(".panels__58331 > div:nth-last-child(1) > div:nth-last-child(1) > button:nth-last-child(1)").addEventListener("click", enterSettings);



    
        // console.log(upperContainer);
        // console.log(topLeftHeader);
        // alert("initd");
    }

    /**
     * Things that happen when you enter a new chat
     */
    function enterChat() {

        let screen = "chat";
        if (document.querySelector("[class^=callContainer_]")) screen = "call";
        
        app.setAttribute("menu", screen);

        // top header of the chat window
        let upperContainer = document.querySelector("[class^=upperContainer_]");

        
        // Back button procedure
        let chatMenuButton = document.createElement("button");
        
        
        chatMenuButton.className = "btnHamburger_df0060 hamburger_d103be chatMenuButton";
        chatMenuButton.type = "button"
        chatMenuButton.ariaLabel = "Channel list";

        /* the hamburger button from the mobile web design literally has just 6 spans. Fun*/
        chatMenuButton.innerHTML = /*html*/ 
        `<span></span><span></span><span></span><span></span><span></span><span></span>`;

        if (upperContainer.querySelector(".chatMenuButton")) { 
            upperContainer.querySelector(".chatMenuButton").replaceWith(chatMenuButton); 
        }
        else { upperContainer.insertAdjacentElement("afterbegin", chatMenuButton); }

        chatMenuButton.addEventListener("click", (e) => {
            e.preventDefault();
            toggleSidebar();
        });



        let notifBadge = document.createElement("div");

        notifBadge.className = "lowerBadge__669e7 notificationBadge";
        notifBadge.innerHTML = //html
        `
        <div class="numberBadge__50328 base__92a12 eyebrow__60985 baseShapeRound__95d0f" id="notifBadgeNumber"></div>
        `;

        chatMenuButton.appendChild(notifBadge);

        

        // Popout button procedure
        let togglePopButton = document.createElement("div");
        togglePopButton
        togglePopButton.className = "togglePopButton";

        togglePopButton.innerHTML = /*html*/ 
        `<div class="iconWrapper_af9215 clickable_d23a1a" role="button" aria-label="Toggle Popout" aria-expanded="false"></div>
        `;

        togglePopButton.children[0].appendChild(generateIconOn("currentColor"));
        togglePopButton.children[0].appendChild(generateIconOff("currentColor"));


        togglePopButton.addEventListener("click", togglePopped);

        // returns early if adding the popbutton isnt necessary rn

        if (screen === "call") {  
            upperContainer.querySelector("[class^=toolbar_]").insertAdjacentElement("afterbegin", togglePopButton);
            return;
        }
            
        // replaces the help button with the toggle popped button
        let replaceTarget = upperContainer.querySelector(".toolbar__88c63 > a");
        
        // if it exists already, replace that intead
        if (app.querySelector(".togglePopButton")) replaceTarget = app.querySelector(".togglePopButton");  
        
        // if no replace target exists, just shove it at the end of the topbar
        if (!replaceTarget) { upperContainer.appendChild(togglePopButton); return;}
        replaceTarget.replaceWith(togglePopButton);
        

    }

    /**
     * Toggles the sidebar
     */
    function toggleSidebar() {

        if (app.getAttribute("sidebarOpen") === "true") {
            app.setAttribute("sidebarOpen", "false");
            return;
        }
        app.setAttribute("sidebarOpen", "true");
        return
        
    }

    /**
     * Sets the app.sidebarOpen attribute to the state given
     * @param {bool} state state of "sidebarOpen"
     */
    function setSidebar(state) {
        app.setAttribute("sidebarOpen", state);
    }

    function enterSettings() {
        if (!isPopped()) return;

        app.setAttribute("settings", "open");
        // console.log("enter")
        let settings = document.querySelector(".standardSidebarView__1129a");        
        
        function addBackButton() {
            // console.info("-------------------");

            if (document.querySelector(".header-title-fix")) { 
                // console.info("removing old header: ", document.querySelector(".header-title-fix"), document.querySelector(".header-title-fix").textContent); 
                document.querySelector(".header-title-fix").remove(); 
            }


            let settingsContainer = settings.querySelector("[class^=contentColumn");
            // console.log("h");
            let settingsContentHeader = settingsContainer.querySelector("h2");

            let headerTitleReplacement = document.createElement("h2");
            headerTitleReplacement.className = "defaultColor__37d78 heading-lg-semibold_a200cd defaultColor__87d87 header-title-fix";
            headerTitleReplacement.setAttribute("data-text-variant", "heading-lg/semibold");

            let tabText = document.querySelector("[class^=sidebar__] [aria-selected='true']").textContent.trim();
            // console.info("tabText is: ", tabText);

            headerTitleReplacement.textContent = tabText;

            let firstTitle = "";
            if (settingsContentHeader) { 
                firstTitle = settingsContentHeader.textContent.trim();
                // console.info("firstTitle is: ", firstTitle)
                // console.log("contentHeader is: ", settingsContentHeader);
            }


            // checks if the first found title is the same as the tab selected
            // if it is, then checks if its on top of the page
            if (firstTitle == tabText) {
                // console.warn("h2 is not the first element");
                // console.log(settingsContentHeader)
                settingsContentHeader.hidden = true;
                settingsContentHeader.ariaHidden = true;
            }

            settingsContainer.insertAdjacentElement("beforebegin", headerTitleReplacement);
            settingsContentHeader = headerTitleReplacement;

            // if (!document.querySelector(".separator")) settingsContentHeader.insertAdjacentHTML("afterend", "<div class='separator'> </div>");
             
            let backButton = document.createElement("button");
            backButton.addEventListener("click", (e) => { 
                e.preventDefault();
                toggleSidebar();
            });

            backButton.className = "settingsBackButton";
            backButton.appendChild(generateIconBack());

            // console.log(settingsContentHeader);
    
            // if it doesnt exists, then add.
            if (!settingsContentHeader.querySelector(".settingsBackButton") ) {
                settingsContentHeader.insertAdjacentElement("afterbegin", backButton);
            }
        }
        
        if (settings.getAttribute("evented") === "true") return;
        let settingsButtons = settings.querySelector("div > div > nav > div");
        
        settings.setAttribute("evented", "true");
        settingsButtons.addEventListener("click", (e) => {
            if (e.target.getAttribute("role") === "tab" || e.target.parentElement.getAttribute("role") === "tab") { 
                // alert("tab"); 
                setTimeout(addBackButton, 0);
                setSidebar(false);
            }
        })

        addBackButton();
        setSidebar(true);

    }

    load();
}
